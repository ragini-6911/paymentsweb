package firstWebApp;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/deletebankaccservlet")
public class deletebankaccservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public deletebankaccservlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
	        int userId = (int) session.getAttribute("userId"); 
	       
	        String bankAcctNoToDelete = request.getParameter("bankAcctNo");

	        // Call a method to delete the bank account from the database
	        boolean deleted = deleteBankAccount(userId, bankAcctNoToDelete);

	}

}
