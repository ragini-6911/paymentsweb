package firstWebApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class jdbc {

	public static void main(String[] args) {
		
		
		try {
			Connection con=null;
			
			 
				 
			  if(con!=null) {
				  Class.forName("com.mysql.cj.jdbc.Driver");
					 
								 
					   con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/userdetails","root","Ragini@2001");
					 
								 Statement stmt = con.createStatement();
								int i= stmt.executeUpdate ("insert into udetails values('honey','kunisetti','12345','kkd','200','abcd')");
							
	System.out.println(i);
}
else {
	System.out.println(con);
}
	}
		catch (Exception e) {
			e.getStackTrace();
			System.out.println(e);
		}

}
}
